package com.mycompany.booktrack;

public class ActiveUserException extends Exception {
    public ActiveUserException(String message) {
        super(message);
    }
}
